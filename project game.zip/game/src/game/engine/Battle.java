package game.engine;

import game.engine.base.Wall;
import game.engine.dataloader.DataLoader;
import game.engine.lanes.Lane;
import game.engine.titans.Titan;
import game.engine.titans.TitanRegistry;
import game.engine.weapons.factory.WeaponFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;

public class Battle {
	private  static final int [][]PHASES_APPROACHING_TITANS=new int [0][0];
	private final int WALL_BASE_HEALTH;
	private int numberOfTurns;
	private int resourcesGathered;
	private BattlePhase battlePhase;
	private int numberOfTitansPerTurn;
	private int score;
	private int titanSpawnDistance;
	private final WeaponFactory weaponFactory;
	private final HashMap<Integer, TitanRegistry> titansArchives;
	private final ArrayList<Titan> approachingTitans;
	private final PriorityQueue<Lane> lanes;
	private final ArrayList<Lane> originalLanes;
	public Battle(int numberOfTurns, int score, int titanSpawnDistance , int initialNumOfLanes , int initialResourcesPerLane )throws IOException {
		super();
		this.numberOfTurns = numberOfTurns;
		this.score = score;
		this.titanSpawnDistance = titanSpawnDistance;
		this.WALL_BASE_HEALTH=1000;
		this.resourcesGathered=initialNumOfLanes*initialResourcesPerLane;
		this.numberOfTitansPerTurn=1;
		this.battlePhase=battlePhase.EARLY;
		this.weaponFactory=new WeaponFactory();
		this.titansArchives=new HashMap<Integer,TitanRegistry>(DataLoader.readTitanRegistry()) ;
		this.approachingTitans=new ArrayList<Titan>();
		this.lanes=new PriorityQueue<Lane>();
		this.lanes.add(new Lane(new Wall(WALL_BASE_HEALTH)));
		this.originalLanes=new ArrayList<Lane>();
	}
	public void setNumberOfTurns(int numberOfTurns) {
		this.numberOfTurns = numberOfTurns;
	}
	public void setResourcesGathered(int resourcesGathered) {
		this.resourcesGathered = resourcesGathered;
	}
	public void setBattlePhase(BattlePhase battlePhase) {
		this.battlePhase = battlePhase;
	}
	public void setNumberOfTitansPerTurn(int numberOfTitansPerTurn ) {
		this.numberOfTitansPerTurn = numberOfTitansPerTurn;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public void setTitanSpawnDistance(int titanSpawnDistance) {
		this.titanSpawnDistance = titanSpawnDistance;
	}
	public int getWALL_BASE_HEALTH() {
		return WALL_BASE_HEALTH;
	}
	public int getNumberOfTurns() {
		return numberOfTurns;
	}
	public int getResourcesGathered() {
		return resourcesGathered;
	}
	public BattlePhase getBattlePhase() {
		return battlePhase;
	}
	public int getNumberOfTitansPerTurn() {
		return numberOfTitansPerTurn;
	}
	public int getScore() {
		return score;
	}
	public int getTitanSpawnDistance() {
		return titanSpawnDistance;
	}
	public WeaponFactory getWeaponFactory() {
		return weaponFactory;
	}
	public HashMap<Integer, TitanRegistry> getTitansArchives() {
		return titansArchives;
	}
	public ArrayList<Titan> getApproachingTitans() {
		return approachingTitans;
	}
	public PriorityQueue<Lane> getLanes() {
		return lanes;
	}
	public ArrayList<Lane> getOriginalLanes() {
		return originalLanes;
	}
	
	
	
}
