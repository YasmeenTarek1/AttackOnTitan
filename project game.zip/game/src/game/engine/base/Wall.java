package game.engine.base;
import game.engine.interfaces.Attackee;
import game.engine.titans.Titan;
public class Wall  implements Attackee  {
	private  final int baseHealth ;
	private int currentHealth;
	private static final int ResourcesValue=-1;
	
	public int getBaseHealth(){
		return baseHealth;
	}
	public int getCurrentHealth(){
		return currentHealth;
	}
	public void setCurrentHealth(int s){
		if (s<=0)
			currentHealth=0;
		currentHealth=s;
	}
	public Wall(int baseHealth){
		this.baseHealth=baseHealth;
		currentHealth=baseHealth;
		
	}
	public int getResourcesValue(){
		return ResourcesValue;
	}
	
}
