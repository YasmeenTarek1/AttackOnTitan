package game.engine.weapons;

public class VolleySpreadCannon extends Weapon{
	public final static int WEAPON_CODE=3;
	private final int minRange;
	private final int maxRange;

	
	public VolleySpreadCannon(int baseDamage ,int min , int max) {
		super(baseDamage);
		minRange=min;
		maxRange=max;
		
	}

	public int getWEAPON_CODE(){
		return WEAPON_CODE;
	}
	public int getMinRange() {
		return minRange;
	}
	public int getMaxRange() {
		return maxRange;
	}
	
	
}
