package game.engine.weapons;

public class  PiercingCannon extends Weapon {
	private final static int WEAPON_CODE =1;

	public PiercingCannon(int baseDamage) {
		super(baseDamage);
		
	}
	
	public PiercingCannon() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getWEAPON_CODE(){
		return WEAPON_CODE;
	}
	
}
