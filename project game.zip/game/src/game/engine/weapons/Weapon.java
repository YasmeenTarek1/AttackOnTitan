package game.engine.weapons;

import game.engine.interfaces.Attacker;

public abstract class Weapon implements Attacker {
	private final int baseDamage;
	
	public Weapon(){
		baseDamage=0;
	}
	public Weapon(int baseDamage) {
		this.baseDamage = baseDamage;
	}
	
	public int getDamage (){
		return baseDamage;
	}
	public static void main (String [] args){
		PiercingCannon c=new PiercingCannon(12);
		System.out.println(c.getWEAPON_CODE());
	}
}
